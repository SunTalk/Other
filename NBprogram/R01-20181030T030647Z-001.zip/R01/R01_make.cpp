#include <bits/stdc++.h>

using namespace std;

const string name = "R01_";

void genData(int n, int i)
{
	freopen((name + to_string(i) + ".in").c_str() , "w", stdout);
	
	printf("%d %d\n", n, rand() % n*10 + 1);
	

	for(int i = 0; i < n; i++)
		printf("%d %d\n", rand() % 10 + 1, rand() % 100 + 1);

}

int main()
{
	srand(time(NULL));
	int n[] = {10, 50, 100, 500, 1000};
	
	for(int i = 0; i < 5; i++)
	{
		genData(n[i], i+1);
	}
	return 0;
}
